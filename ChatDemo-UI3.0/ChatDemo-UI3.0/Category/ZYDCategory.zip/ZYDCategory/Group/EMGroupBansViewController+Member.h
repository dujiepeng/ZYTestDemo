//
//  EMGroupBansViewController+Member.h
//  ChatDemo-UI3.0
//
//  Created by EaseMob on 2017/3/9.
//  Copyright © 2017年 EaseMob. All rights reserved.
//

#import "EMGroupBansViewController.h"

@interface EMGroupBansViewController (Member)

@end
