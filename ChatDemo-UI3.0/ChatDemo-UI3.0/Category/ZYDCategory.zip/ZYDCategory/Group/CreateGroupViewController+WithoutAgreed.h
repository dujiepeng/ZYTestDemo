//
//  CreateGroupViewController+WithoutAgreed.h
//  ChatDemo-UI3.0
//
//  Created by EaseMob on 2017/3/10.
//  Copyright © 2017年 EaseMob. All rights reserved.
//

#import "CreateGroupViewController.h"

@interface CreateGroupViewController (WithoutAgreed)

@property (nonatomic) BOOL withoutAgreed;

@end
