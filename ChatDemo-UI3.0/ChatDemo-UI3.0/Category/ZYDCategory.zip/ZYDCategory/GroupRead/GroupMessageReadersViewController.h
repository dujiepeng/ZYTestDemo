//
//  GroupMessageReadersViewController.h
//  ChatDemo-UI3.0
//
//  Created by WYZ on 2017/3/10.
//  Copyright © 2017年 WYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroupMessageReadersViewController : UITableViewController

@property (nonatomic, strong) NSArray *dataArray;

@end
