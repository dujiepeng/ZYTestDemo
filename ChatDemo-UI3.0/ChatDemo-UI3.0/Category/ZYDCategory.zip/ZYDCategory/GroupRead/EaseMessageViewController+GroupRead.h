//
//  EaseMessageViewController+GroupRead.h
//  ChatDemo-UI3.0
//
//  Created by WYZ on 2017/3/9.
//  Copyright © 2017年 WYZ. All rights reserved.
//

#import "EaseMessageViewController.h"


@interface EaseMessageViewController (GroupRead)

@end
