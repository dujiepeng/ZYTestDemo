//
//  ConversationListController+GroupRead.h
//  ChatDemo-UI3.0
//
//  Created by WYZ on 2017/3/11.
//  Copyright © 2017年 WYZ. All rights reserved.
//

#import "ConversationListController.h"

@interface ConversationListController (GroupRead)

@end
