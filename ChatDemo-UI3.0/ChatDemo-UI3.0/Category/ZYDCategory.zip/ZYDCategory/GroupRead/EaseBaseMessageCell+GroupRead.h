//
//  EaseBaseMessageCell+GroupRead.h
//  ChatDemo-UI3.0
//
//  Created by WYZ on 2017/3/10.
//  Copyright © 2017年 WYZ. All rights reserved.
//

#import "EaseBaseMessageCell.h"

@interface EaseBaseMessageCell (GroupRead)

@end
