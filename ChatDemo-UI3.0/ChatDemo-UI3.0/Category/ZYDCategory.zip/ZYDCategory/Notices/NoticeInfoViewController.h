//
//  NoticeInfoViewController.h
//  ChatDemo-UI3.0
//
//  Created by 杜洁鹏 on 27/02/2017.
//  Copyright © 2017 杜洁鹏. All rights reserved.
//

#import <UIKit/UIKit.h>
@class EMMessage;
@interface NoticeInfoViewController : UIViewController
- (instancetype)initWithMessage:(EMMessage *)aMessage;
@end
